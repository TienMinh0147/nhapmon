package edu.poly.lab.repositories;

import org.springframework.data.repository.CrudRepository;

import edu.poly.lab.models.records;

public interface RecordRepository extends CrudRepository<records, Integer>{

}
